using System;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    // Game Count down timer 
    int currentTime = 10;

    public Text timerUI;

    // Game Starting
    public bool isGameStarted = false;

    // Assiginig rotation speed to Game Object
    public float roatationRate = 50.0f;

    // Player Vertical Input
    private float verticalInput;

    // Player Horizontal Input
    private float horizontalInput;


    // Start is called before the first frame update
    void Start()
    {
        // Calling Timer function
        countDownTimer();
    }

    // Update is called once per frame
    void Update()
    {
        // Instruction to set value
        Debug.Log("Set isGameStarted true to Control Player from Inspector");

        if (isGameStarted == true)
        {
            // Increase Cube size
            if (Input.GetKey("space"))
            {
                transform.localScale += new Vector3(0.2f, 0.2f, 0.2f) * Time.deltaTime;
            }
            else
            {
                transform.localScale = new Vector3(1f, 1f, 1f);
            }

            // Rotate Cute rigt/left
            horizontalInput = Input.GetAxis("Horizontal");

            // Rotate Cube up/down
            verticalInput = Input.GetAxis("Vertical");


            // Rotate Cube on Vertical Input
            transform.Rotate(Vector3.right * roatationRate * Time.deltaTime * verticalInput);

            // Rotate Cube on Horizontal Input
            transform.Rotate(Vector3.forward * roatationRate * Time.deltaTime * horizontalInput);
           
        }
    }


    void countDownTimer()
    {
        if(currentTime > 0)
        {
            TimeSpan timeUI = TimeSpan.FromSeconds(currentTime);
            timerUI.text = "Timer : " + timeUI.Minutes + " : " + timeUI.Seconds;
            currentTime--;
            Invoke("countDownTimer", 1.0f);
        }
        else
        {
            timerUI.text="Time is Completed";
        }
    }
}
